(() => {
  const url = window.SKILLBRIDGE_SUPABASE_URL;
  const key = window.SKILLBRIDGE_SUPABASE_PUBLISHABLE_KEY;

  if (!window.supabase || !url || !key) {
    throw new Error("Supabase is not configured.");
  }

  const db = window.supabase.createClient(url, key);
  const state = { token: null };

  const message = error => error?.message || "Something went wrong.";

  const userShape = (profile, user) => ({
    id: user.id,
    email: user.email,
    role: profile.role,
    profile: profile.profile || {}
  });

  const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[char]));

  async function active() {
    const {
      data: { user },
      error
    } = await db.auth.getUser();

    if (error || !user) throw new Error("Please sign in first.");

    const {
      data: profile,
      error: profileError
    } = await db
      .from("profiles")
      .select("role, profile")
      .eq("id", user.id)
      .single();

    if (profileError) throw new Error(message(profileError));

    return { user, profile, safe: userShape(profile, user) };
  }

  async function syncAuthState() {
    const {
      data: { session }
    } = await db.auth.getSession();

    state.token = session?.access_token || null;

    if (session?.user) {
      localStorage.setItem("skillbridge_token", session.access_token);
    } else {
      localStorage.removeItem("skillbridge_token");
    }
  }

  function saveSession(session, user) {
    state.token = session.access_token;
    localStorage.setItem("skillbridge_token", session.access_token);
    localStorage.setItem("skillbridge_user", JSON.stringify(user));
    localStorage.setItem("skillbridge_role", user.role);
  }

  function normalizeSkill(value) {
    return String(value || "").trim().toLowerCase();
  }

  function match(profile, opportunity) {
    const career = {
      "web development": ["html", "css", "javascript"],
      "data science": ["python", "sql", "data analysis"],
      "ai/ml": ["python", "machine learning"],
      "cloud/devops": ["cloud", "linux", "networking"],
      cybersecurity: ["networking", "cybersecurity"]
    };

    const skills = new Set([
      ...(profile.skills || []),
      ...(career[String(profile.career || "").toLowerCase()] || [])
    ].map(normalizeSkill));

    const required = opportunity.required_skills || [];
    const matchedSkills = required.filter(skill => skills.has(normalizeSkill(skill)));
    const missingSkills = required.filter(skill => !skills.has(normalizeSkill(skill)));

    const percentage = Math.min(
      (required.length ? Math.round(matchedSkills.length / required.length * 70) : 0) +
      Math.min(Number(profile.projects || 0) * 5 + Number(profile.courses || 0) * 3, 30),
      100
    );

    return {
      percentage,
      matchedSkills,
      missingSkills,
      explanation: matchedSkills.length
        ? `You match ${matchedSkills.join(", ")}. Strengthen ${missingSkills.length ? missingSkills.join(", ") : "your project evidence"} to improve this match.`
        : `This role needs ${required.join(", ")}. Start with the listed skills and add a related project.`
    };
  }

  window.SkillBridgeAPI = {
    get token() {
      return state.token || localStorage.getItem("skillbridge_token");
    },

    escapeHtml,

    async register({ email, password, role }) {
      if (role !== "student") {
        throw new Error(
          "Institute and industry workspaces must be provisioned by the platform administrator. " +
          "This prevents a new user from granting themselves elevated workspace permissions."
        );
      }

      const { data, error } = await db.auth.signUp({
        email,
        password
      });

      if (error) throw new Error(message(error));

      if (!data.session) {
        return {
          needsEmailConfirmation: true,
          user: { email, role: "student", profile: {} }
        };
      }

      const current = await active();
      saveSession(data.session, current.safe);

      return {
        token: data.session.access_token,
        user: current.safe
      };
    },

    async login({ email, password, role }) {
      const { data, error } = await db.auth.signInWithPassword({
        email,
        password
      });

      if (error || !data.session) throw new Error(message(error));

      const current = await active();

      if (current.profile.role !== role) {
        await db.auth.signOut();
        throw new Error(
          `This account belongs to the ${current.profile.role} workspace, not the ${role} workspace.`
        );
      }

      saveSession(data.session, current.safe);
      return {
        token: data.session.access_token,
        user: current.safe
      };
    },

    async request(path, options = {}) {
      const method = (options.method || "GET").toUpperCase();
      const body = options.body ? JSON.parse(options.body) : {};
      const current = await active();

      if (path === "/api/me/profile" && method === "GET") {
        return { user: current.safe };
      }

      if (path === "/api/me/profile" && method === "PUT") {
        const nextProfile = {
          ...current.profile.profile,
          ...body
        };

        const { data, error } = await db
          .from("profiles")
          .update({
            profile: nextProfile,
            updated_at: new Date().toISOString()
          })
          .eq("id", current.user.id)
          .select("role, profile")
          .single();

        if (error) throw new Error(message(error));

        const user = userShape(data, current.user);
        localStorage.setItem("skillbridge_user", JSON.stringify(user));
        localStorage.setItem("skillbridge_profile", JSON.stringify(data.profile || {}));

        return { user };
      }

      if (path === "/api/opportunities" && method === "GET") {
        let opportunityQuery = db
          .from("opportunities")
          .select("*")
          .order("created_at", { ascending: false });

        if (current.profile.role === "industry") {
          opportunityQuery = opportunityQuery.eq("created_by", current.user.id);
        }

        const { data, error } = await opportunityQuery;

        if (error) throw new Error(message(error));

        return {
          opportunities: (data || []).map(item => ({
            id: item.id,
            title: item.title,
            company: item.company,
            type: item.type,
            location: item.location,
            workMode: item.work_mode,
            requiredSkills: item.required_skills,
            description: item.description,
            createdBy: item.created_by,
            createdAt: item.created_at,
            match: current.profile.role === "student"
              ? match(current.profile.profile, item)
              : undefined
          }))
        };
      }

      if (path === "/api/opportunities" && method === "POST") {
        if (current.profile.role !== "industry") {
          throw new Error("Only industry accounts can create opportunities.");
        }

        const skills = Array.isArray(body.requiredSkills)
          ? body.requiredSkills.map(String).map(s => s.trim()).filter(Boolean)
          : [];

        if (!skills.length) {
          throw new Error("Add at least one required skill.");
        }

        const { data, error } = await db
          .from("opportunities")
          .insert({
            company: String(body.company || "").trim(),
            title: String(body.title || "").trim(),
            type: body.type || "internship",
            work_mode: body.workMode || "hybrid",
            location: String(body.location || "India").trim(),
            required_skills: skills,
            description: String(body.description || "").trim(),
            created_by: current.user.id
          })
          .select("*")
          .single();

        if (error) throw new Error(message(error));

        return {
          opportunity: {
            id: data.id,
            title: data.title,
            company: data.company
          }
        };
      }

      if (path === "/api/applications" && method === "GET") {
        let query = db
          .from("applications")
          .select("id, opportunity_id, student_id, status, created_at, opportunities(title, company, type, location, work_mode, required_skills)")
          .order("created_at", { ascending: false });

        if (current.profile.role === "student") {
          query = query.eq("student_id", current.user.id);
        }

        const { data, error } = await query;

        if (error) throw new Error(message(error));

        return {
          applications: (data || []).map(row => ({
            id: row.id,
            opportunityId: row.opportunity_id,
            studentId: row.student_id,
            status: row.status,
            createdAt: row.created_at,
            opportunity: row.opportunities || {}
          }))
        };
      }

      const statusMatch = path.match(/^\/api\/applications\/([^/]+)$/);
      if (statusMatch && method === "PATCH") {
        if (current.profile.role !== "industry") {
          throw new Error("Only industry accounts can update application status.");
        }

        const allowed = new Set(["submitted", "reviewed", "accepted", "rejected"]);
        if (!allowed.has(body.status)) {
          throw new Error("Invalid application status.");
        }

        const { data, error } = await db
          .from("applications")
          .update({ status: body.status })
          .eq("id", statusMatch[1])
          .select("id, opportunity_id, student_id, status, created_at")
          .single();

        if (error) throw new Error(message(error));
        return { application: data };
      }

      const application = path.match(/^\/api\/opportunities\/([^/]+)\/apply$/);
      if (application && method === "POST") {
        if (current.profile.role !== "student") {
          throw new Error("Only student accounts can apply.");
        }

        const { data, error } = await db
          .from("applications")
          .insert({
            opportunity_id: application[1],
            student_id: current.user.id
          })
          .select("*")
          .single();

        if (error) {
          if (String(error.code) === "23505") {
            throw new Error("You have already applied to this opportunity.");
          }
          throw new Error(message(error));
        }

        return { application: data };
      }

      throw new Error("Unsupported request.");
    },

    async logout() {
      state.token = null;
      ["skillbridge_token", "skillbridge_user", "skillbridge_role"].forEach(key =>
        localStorage.removeItem(key)
      );
      localStorage.removeItem("skillbridge_profile");
      await db.auth.signOut();
      window.location.href = "login.html";
    },

    async currentUser() {
      return active();
    }
  };

  db.auth.onAuthStateChange((event, session) => {
    state.token = session?.access_token || null;
    if (session?.access_token) {
      localStorage.setItem("skillbridge_token", session.access_token);
    } else {
      localStorage.removeItem("skillbridge_token");
    }
  });

  syncAuthState().catch(() => {
    state.token = localStorage.getItem("skillbridge_token");
  });
})();