-- SkillBridge AI production foundation.
-- Run once in Supabase SQL Editor for a fresh project.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  role text not null check (role in ('student', 'institute', 'industry')),
  profile jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.opportunities (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  company text not null,
  type text not null default 'internship' check (type in ('internship','job','project')),
  location text not null default 'India',
  work_mode text not null default 'hybrid' check (work_mode in ('hybrid','remote','onsite')),
  required_skills text[] not null check (cardinality(required_skills) > 0),
  description text not null default '',
  created_by uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  opportunity_id uuid not null references public.opportunities(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'submitted' check (status in ('submitted','reviewed','accepted','rejected')),
  created_at timestamptz not null default now(),
  unique (opportunity_id, student_id)
);

create or replace function public.create_profile_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, coalesce(new.email, ''), 'student');
  return new;
end;
$$;

revoke execute on function public.create_profile_for_new_user() from public, anon, authenticated;
grant execute on function public.create_profile_for_new_user() to postgres, service_role;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.create_profile_for_new_user();

create or replace function public.prevent_profile_identity_change()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if new.id <> old.id or new.email <> old.email or new.role <> old.role then
    raise exception 'Profile identity fields cannot be changed directly';
  end if;
  return new;
end;
$$;

create or replace function public.prevent_application_identity_change()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if new.id <> old.id
     or new.opportunity_id <> old.opportunity_id
     or new.student_id <> old.student_id then
    raise exception 'Application identity fields cannot be changed directly';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_prevent_profile_identity_change on public.profiles;
create trigger trg_prevent_profile_identity_change
before update on public.profiles
for each row execute function public.prevent_profile_identity_change();

drop trigger if exists trg_prevent_application_identity_change on public.applications;
create trigger trg_prevent_application_identity_change
before update on public.applications
for each row execute function public.prevent_application_identity_change();

create index if not exists applications_student_id_idx
  on public.applications (student_id);

create index if not exists opportunities_created_by_idx
  on public.opportunities (created_by);

alter table public.profiles enable row level security;
alter table public.opportunities enable row level security;
alter table public.applications enable row level security;

drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own
on public.profiles for select
to authenticated
using ((select auth.uid()) = id);

drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own
on public.profiles for update
to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);

drop policy if exists opportunities_select_authenticated on public.opportunities;
create policy opportunities_select_authenticated
on public.opportunities for select
to authenticated
using (true);

drop policy if exists industry_creates_opportunities on public.opportunities;
create policy industry_creates_opportunities
on public.opportunities for insert
to authenticated
with check (
  (select auth.uid()) = created_by
  and exists (
    select 1
    from public.profiles
    where id = (select auth.uid())
      and role = 'industry'
  )
);

drop policy if exists industry_updates_own_opportunities on public.opportunities;
create policy industry_updates_own_opportunities
on public.opportunities for update
to authenticated
using (
  created_by = (select auth.uid())
  and exists (
    select 1
    from public.profiles
    where id = (select auth.uid())
      and role = 'industry'
  )
)
with check (created_by = (select auth.uid()));

drop policy if exists industry_deletes_own_opportunities on public.opportunities;
create policy industry_deletes_own_opportunities
on public.opportunities for delete
to authenticated
using (
  created_by = (select auth.uid())
  and exists (
    select 1
    from public.profiles
    where id = (select auth.uid())
      and role = 'industry'
  )
);

drop policy if exists applications_select_own_or_owned on public.applications;
create policy applications_select_own_or_owned
on public.applications for select
to authenticated
using (
  student_id = (select auth.uid())
  or exists (
    select 1
    from public.opportunities o
    where o.id = opportunity_id
      and o.created_by = (select auth.uid())
  )
);

drop policy if exists students_apply_once on public.applications;
create policy students_apply_once
on public.applications for insert
to authenticated
with check (
  (select auth.uid()) = student_id
  and exists (
    select 1
    from public.profiles
    where id = (select auth.uid())
      and role = 'student'
  )
);

drop policy if exists industry_update_application_status on public.applications;
create policy industry_update_application_status
on public.applications for update
to authenticated
using (
  exists (
    select 1
    from public.opportunities o
    join public.profiles p on p.id = (select auth.uid())
    where o.id = opportunity_id
      and o.created_by = (select auth.uid())
      and p.role = 'industry'
  )
)
with check (
  exists (
    select 1
    from public.opportunities o
    where o.id = opportunity_id
      and o.created_by = (select auth.uid())
  )
);

-- Institute/industry accounts should be provisioned by a trusted administrator
-- using app_metadata or the Supabase dashboard; raw user_metadata is never
-- used for authorization.
